Python 3.12.4 (tags/v3.12.4:8e8a4ba, Jun  6 2024, 19:30:16) [MSC v.1940 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.

= RESTART: C:\Users\kunda\AppData\Local\Programs\Python\Python312\python project 37.py
20
Enter name:varsha
Enter the gender:female
Enter the location:ongole
Enter product name:watch
Enter rating for quality 1 to 5:5
Enter color matching (yes/no:yes
Enter product is damage or not(yes/no):no
Enter your rating:5
Enter name:hema
Enter the gender:female
Enter the location:ongole
Enter product name:glasses
Enter rating for quality 1 to 5:4
Enter color matching (yes/no:yes
Enter product is damage or not(yes/no):no
Enter your rating:4
Enter name:vyshu
Enter the gender:female
Enter the location:vijayawada
Enter product name:shirt
Enter rating for quality 1 to 5:4
Enter color matching (yes/no:no
Enter product is damage or not(yes/no):yes
Enter your rating:4
Enter name:teju
Enter the gender:female
Enter the location:guntur
Enter product name:pant
Enter rating for quality 1 to 5:4
Enter color matching (yes/no:yes
Enter product is damage or not(yes/no):no
Enter your rating:3
Enter name:renu
Enter the gender:male
Enter the location:ongole'
Enter product name:shoes
Enter rating for quality 1 to 5:5
Enter color matching (yes/no:no
Enter product is damage or not(yes/no):no
Enter your rating:4
Enter name:venky
Enter the gender:male
Enter the location:ongole
Enter product name:gold
Enter rating for quality 1 to 5:4
Enter color matching (yes/no:yes
Enter product is damage or not(yes/no):no
Enter your rating:4
Enter name:lokki
Enter the gender:male
Enter the location:snapdu
Enter product name:ring
Enter rating for quality 1 to 5:4
Enter color matching (yes/no:yes
Enter product is damage or not(yes/no):no
Enter your rating:4
Enter name:laxman
Enter the gender:male
Enter the location:ngpadu
Enter product name:bottle
Enter rating for quality 1 to 5:4
Enter color matching (yes/no:4
Enter product is damage or not(yes/no):no
Enter your rating:5
Enter name:susmi
Enter the gender:female
Enter the location:snpadu
Enter product name:laptop
Enter rating for quality 1 to 5:5
Enter color matching (yes/no:yes
Enter product is damage or not(yes/no):no
Enter your rating:4
Enter name:abhi
Enter the gender:male
Enter the location:ongole
Enter product name:watch
Enter rating for quality 1 to 5:5
Enter color matching (yes/no:yes
Enter product is damage or not(yes/no):no
Enter your rating:4
Enter name:vinay
Enter the gender:male
Enter the location:ongole
Enter product name:phone
Enter rating for quality 1 to 5:4
Enter color matching (yes/no:yes
Enter product is damage or not(yes/no):no
Enter your rating:5
Enter name:akhila
Enter the gender:female
Enter the location:naddipadu
Enter product name:dress
Enter rating for quality 1 to 5:4
Enter color matching (yes/no:yes
Enter product is damage or not(yes/no):no
Enter your rating:4
Enter name:raga
Enter the gender:female
Enter the location:ongole
Enter product name:watch
Enter rating for quality 1 to 5:3
Enter color matching (yes/no:no
Enter product is damage or not(yes/no):yes
Enter your rating:3
Enter name:ravi
Enter the gender:male
Enter the location:ongole
Enter product name:phone
Enter rating for quality 1 to 5:4
Enter color matching (yes/no:yes
Enter product is damage or not(yes/no):no
Enter your rating:4
Enter name:teja
Enter the gender:male
Enter the location:ong
Enter product name:dress
Enter rating for quality 1 to 5:4
Enter color matching (yes/no:no
Enter product is damage or not(yes/no):yes
Enter your rating:4
Enter name:ravi teja
Enter the gender:ma;le
Enter the location:ongole
Enter product name:mouse
Enter rating for quality 1 to 5:3
Enter color matching (yes/no:no
Enter product is damage or not(yes/no):yes
Enter your rating:3
Enter name:susma
Enter the gender:female
Enter the location:hyd
Enter product name:bag
Enter rating for quality 1 to 5:3
Enter color matching (yes/no:yes
Enter product is damage or not(yes/no):no
Enter your rating:4
Enter name:harini
Enter the gender:female
Enter the location:onole
Enter product name:chair
Enter rating for quality 1 to 5:4
Enter color matching (yes/no:yes
Enter product is damage or not(yes/no):no
Enter your rating:4
Enter name:sai
Enter the gender:male
Enter the location:ongole
Enter product name:watch
Enter rating for quality 1 to 5:3
Enter color matching (yes/no:yes
Enter product is damage or not(yes/no):no
Enter your rating:3
Enter name:sai teja
Enter the gender:male
Enter the location:hyd
Enter product name:bag
Enter rating for quality 1 to 5:3
Enter color matching (yes/no:yes
Enter product is damage or not(yes/no):no
Enter your rating:3
         name  gender    location  product  quality color damage  rating
0      varsha  female      ongole    watch        5   yes     no       5
1        hema  female      ongole  glasses        4   yes     no       4
2       vyshu  female  vijayawada    shirt        4    no    yes       4
3        teju  female      guntur     pant        4   yes     no       3
4        renu    male     ongole'    shoes        5    no     no       4
5       venky    male      ongole     gold        4   yes     no       4
6       lokki    male      snapdu     ring        4   yes     no       4
7      laxman    male      ngpadu   bottle        4     4     no       5
8       susmi  female      snpadu   laptop        5   yes     no       4
9        abhi    male      ongole    watch        5   yes     no       4
10      vinay    male      ongole    phone        4   yes     no       5
11     akhila  female   naddipadu    dress        4   yes     no       4
12       raga  female      ongole    watch        3    no    yes       3
13       ravi    male      ongole    phone        4   yes     no       4
14       teja    male         ong    dress        4    no    yes       4
15  ravi teja   ma;le      ongole    mouse        3    no    yes       3
16      susma  female         hyd      bag        3   yes     no       4
17     harini  female       onole    chair        4   yes     no       4
18        sai    male      ongole    watch        3   yes     no       3
19   sai teja    male         hyd      bag        3   yes     no       3
how many are male: 0
How many are female: 0
Quality of product more than or equal 3: varsha 5
Quality of product more than or equal 3: hema 4
Quality of product more than or equal 3: vyshu 4
Quality of product more than or equal 3: teju 4
Quality of product more than or equal 3: renu 5
Quality of product more than or equal 3: venky 4
Quality of product more than or equal 3: lokki 4
Quality of product more than or equal 3: laxman 4
Quality of product more than or equal 3: susmi 5
Quality of product more than or equal 3: abhi 5
Quality of product more than or equal 3: vinay 4
Quality of product more than or equal 3: akhila 4
Quality of product more than or equal 3: ravi 4
Quality of product more than or equal 3: teja 4
Quality of product more than or equal 3: harini 4
How many persons got correct color based on order: 14
How many persons got the wrong color based on order: 5
How many persons got damage product: 4
How many persons got no danage of product: 16
Rating more than or equal to 3: varsha
Rating more than or equal to 3: hema
Rating more than or equal to 3: vyshu
Rating more than or equal to 3: teju
Rating more than or equal to 3: renu
Rating more than or equal to 3: venky
Rating more than or equal to 3: lokki
Rating more than or equal to 3: laxman
Rating more than or equal to 3: susmi
Rating more than or equal to 3: abhi
Rating more than or equal to 3: vinay
Rating more than or equal to 3: akhila
Rating more than or equal to 3: raga
Rating more than or equal to 3: ravi
Rating more than or equal to 3: teja
Rating more than or equal to 3: ravi teja
Rating more than or equal to 3: susma
Rating more than or equal to 3: harini
Rating more than or equal to 3: sai
Rating more than or equal to 3: sai teja
renu
renu male ongole' shoes 5 no no 4
