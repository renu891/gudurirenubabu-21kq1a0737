import pandas as pd
r=[]
def add_feedback(name,gender,location,product,quality,color,damage,rating):
    feedback={
        'name':name,
        'gender':gender,
        'location':location,
        'product':product,
        'quality':quality,
        'color':color,
        'damage':damage,
        'rating':rating
    }
    r.append(feedback)
n=int(input())
for _ in range(n):
    name=input("Enter name:")
    gender=input("Enter the gender:")
    location=input("Enter the location:")
    product=input("Enter product name:")
    quality=int(input("Enter rating for quality 1 to 5:"))
    color=input("Enter color matching (yes/no:")
    damage=input("Enter product is damage or not(yes/no):")
    rating=int(input("Enter your rating:"))
    add_feedback(name,gender,location,product,quality,color,damage,rating)   
'''for i in range(n):
    print(s[i])'''
df=pd.DataFrame(r)
print(df)
c1=0
for i in range(n):
    if r[i]['gender'] == 'm':
        c1+=1
print("how many are male:",c1)
c2=0
for i in range(n):
    if r[i]['gender'] == 'f':
        c2+=1
print("How many are female:",c2)
for i in range(n):
    if r[i]['quality'] < 3:
        print("Quality of product less than 3:",r[i]['name'],r[i]['quality'])
for i in range(n):
    if r[i]['quality'] > 3:
        print("Quality of product more than or equal 3:",r[i]['name'],r[i]['quality'])
c1=0
for i in range(n):
    if r[i]['color'] == 'yes':
       c1+=1
print("How many persons got correct color based on order:",c1)
c2=0
for i in range(n):
    if r[i]['color'] == 'no':
        c2+=1
print("How many persons got the wrong color based on order:",c2)
c3=0
for i in range(n):
    if r[i]['damage'] =='yes':
       c3+=1
print("How many persons got damage product:",c3)
c4=0
for i in range(n):
    if r[i]['damage'] == 'no':
        c4+=1
print("How many persons got no danage of product:",c4)
for i in range(n):
    if r[i]['rating'] < 3:
        print("Rating less than 3:",r[i]['name'])
for i in range(n):
    if r[i]['rating'] >= 3:
        print("Rating more than or equal to 3:",r[i]['name'])
N=input()
for i in range(n):
    if r[i]['name']==N:
        print(r[i]['name'],r[i]['gender'],r[i]['location'],r[i]['product'],r[i]['quality'],r[i]['color'],r[i]['damage'],r[i]['rating'])

        



